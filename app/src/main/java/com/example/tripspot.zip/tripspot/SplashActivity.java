package com.example.tripspot;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_TIME_OUT = 6000; // 6 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Set the text for the splash screen
        TextView tripifyText = findViewById(R.id.tripifyText);
        TextView sloganText = findViewById(R.id.sloganText);

        tripifyText.setText("Tripify");
        sloganText.setText("Let's travel the world with us");

        // Navigate to SignupActivity after 6 seconds
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, SignupAcitivity.class);
                startActivity(intent);
                finish(); // close the SplashActivity
            }
        }, SPLASH_TIME_OUT);
    }
}