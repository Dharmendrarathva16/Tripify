package com.example.tripspot;

public class HelperClass {
}
